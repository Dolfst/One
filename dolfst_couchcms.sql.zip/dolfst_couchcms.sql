-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Окт 24 2014 г., 00:06
-- Версия сервера: 5.6.16-64.0-beget-log
-- Версия PHP: 5.4.31

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `dolfst_couchcms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `couch_attachments`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_attachments`;
CREATE TABLE IF NOT EXISTS `couch_attachments` (
  `attach_id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `file_real_name` varchar(255) NOT NULL,
  `file_disk_name` varchar(255) NOT NULL,
  `file_extension` varchar(255) NOT NULL,
  `file_size` int(20) unsigned NOT NULL DEFAULT '0',
  `file_time` int(10) unsigned NOT NULL DEFAULT '0',
  `is_orphan` tinyint(1) unsigned DEFAULT '1',
  `hit_count` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`attach_id`),
  KEY `couch_attachments_Index01` (`is_orphan`),
  KEY `couch_attachments_Index02` (`file_time`),
  KEY `couch_attachments_Index03` (`is_orphan`,`file_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `couch_comments`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_comments`;
CREATE TABLE IF NOT EXISTS `couch_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tpl_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` tinytext,
  `email` varchar(128) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `ip_addr` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `data` text,
  `approved` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `couch_comments_Index01` (`date`),
  KEY `couch_comments_Index02` (`page_id`,`approved`,`date`),
  KEY `couch_comments_Index03` (`tpl_id`,`approved`,`date`),
  KEY `couch_comments_Index04` (`approved`,`date`),
  KEY `couch_comments_Index05` (`tpl_id`,`page_id`,`approved`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `couch_data_numeric`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_data_numeric`;
CREATE TABLE IF NOT EXISTS `couch_data_numeric` (
  `page_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` decimal(65,2) DEFAULT '0.00',
  PRIMARY KEY (`page_id`,`field_id`),
  KEY `couch_data_numeric_Index01` (`value`),
  KEY `couch_data_numeric_Index02` (`field_id`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `couch_data_text`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_data_text`;
CREATE TABLE IF NOT EXISTS `couch_data_text` (
  `page_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` longtext,
  `search_value` text,
  PRIMARY KEY (`page_id`,`field_id`),
  KEY `couch_data_text_Index01` (`search_value`(255)),
  KEY `couch_data_text_Index02` (`field_id`,`search_value`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `couch_data_text`
--

INSERT INTO `couch_data_text` (`page_id`, `field_id`, `value`, `search_value`) VALUES
(1, 1, '', ''),
(1, 2, '', ''),
(2, 3, '<p>Hello WORLD!</p>\r\n', 'Hello WORLD!'),
(2, 4, ':8330263.jpg', '8330263.jpg'),
(3, 3, '<p><font>Хело Ворлд, ахахха&nbsp;</font></p>\r\n\r\n<p><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Все выглядит хорошо на данный момент.&nbsp;</font><em style="border: 0px; font-size: 16px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; line-height: 22.3999996185303px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">&quot;Подробнее .. &#39;</em><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">&nbsp;кнопку в нижней части каждой должности необходим внимание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем использовать тег excerptHTML для наших целей.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Он может быть дополнительно настроен игнорировать определенные теги HTML.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы установим счетчик слов для выписки до 75.&nbsp;Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Все выглядит хорошо на данный момент.&nbsp;</font><em style="border: 0px; font-size: 16px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; line-height: 22.3999996185303px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">&quot;Подробнее .. &#39;</em><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">&nbsp;кнопку в нижней части каждой должности необходим внимание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем использовать тег excerptHTML для наших целей.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Он может быть дополнительно настроен игнорировать определенные теги HTML.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы установим счетчик слов для выписки до 75.&nbsp;Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Все выглядит хорошо на данный момент.&nbsp;</font><em style="border: 0px; font-size: 16px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; line-height: 22.3999996185303px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;">&quot;Подробнее .. &#39;</em><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">&nbsp;кнопку в нижней части каждой должности необходим внимание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем использовать тег excerptHTML для наших целей.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Он может быть дополнительно настроен игнорировать определенные теги HTML.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Мы установим счетчик слов для выписки до 75.&nbsp;</font><font style="color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; font-size: 16px; line-height: 22.3999996185303px;">Модифицированный код IS-</font></p>\r\n', 'Хело Ворлд, ахахха  Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS-'),
(3, 4, ':8330263.jpg', '8330263.jpg'),
(4, 5, '<p>Привет, сайт еще в разработке&nbsp;</p>\r\n\r\n<p><img alt="laugh" height="23" src="http://dolfst.bget.ru/couch/includes/ckeditor/plugins/smiley/images/teeth_smile.png" title="laugh" width="23" /></p>\r\n', 'Привет, сайт еще в разработке '),
(4, 6, ':8330263-1.jpg', '8330263-1.jpg'),
(5, 5, '<h3 style="border: 0px; font-size: 1.218em; margin: 0px 0px 2.919px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><font>Листинг клонированных СТРАНИЦЫ - список-вид</font></h3>\r\n\r\n<p style="border: 0px; font-size: 16px; margin: 0px 0px 1.4em; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; line-height: 22.3999996185303px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><font>Как уже говорилось, </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;http://www.mytestsite.com/blog.php</font></em><font> &nbsp;является вид, в котором перечислены все существующие записи в блоге. </font><br />\r\n<font>доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. </font><br />\r\n<font>Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;blog.php</font></em><font> &nbsp;шаблона в порядке убывания их даты публикации. </font><font>То, как мы настроили его, шаблон&nbsp; </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>blog.php</font></em><font> &nbsp;использует встроенный шаблон&nbsp; </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>blog_list.html</font></em><font> &nbsp;оказывать-список вид . </font><font>файла </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;blog_list.html&nbsp;</font></em><font> , где мы будем делать изменения сейчас. </font><font>Откройте его в текстовом редакторе. </font><font>Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. </font><font>Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. </font><font>Синтаксис страниц тег довольно прост.</font><br />\r\n<br />\r\n<br />\r\n<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n\r\n<h3 style="border: 0px; font-size: 1.218em; margin: 0px 0px 2.919px; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><font>Листинг клонированных СТРАНИЦЫ - список-вид</font></h3>\r\n\r\n<p style="border: 0px; font-size: 16px; margin: 0px 0px 1.4em; outline: 0px; padding: 0px; vertical-align: baseline; color: rgb(37, 37, 37); font-family: ''PT Sans'', sans-serif; line-height: 22.3999996185303px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;"><font>Как уже говорилось, </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;http://www.mytestsite.com/blog.php</font></em><font> &nbsp;является вид, в котором перечислены все существующие записи в блоге. </font><br />\r\n<font>доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. </font><br />\r\n<font>Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;blog.php</font></em><font> &nbsp;шаблона в порядке убывания их даты публикации. </font><font>То, как мы настроили его, шаблон&nbsp; </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>blog.php</font></em><font> &nbsp;использует встроенный шаблон&nbsp; </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>blog_list.html</font></em><font> &nbsp;оказывать-список вид . </font><font>файла </font><em style="border: 0px; margin: 0px; outline: 0px; padding: 0px; vertical-align: baseline; background: transparent;"><font>&nbsp;blog_list.html&nbsp;</font></em><font> , где мы будем делать изменения сейчас. </font><font>Откройте его в текстовом редакторе. </font><font>Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. </font><font>Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. </font><font>Синтаксис страниц тег довольно прост.</font><br />\r\n<br />\r\n<br />\r\n<br />\r\n<br />\r\n<br />\r\n&nbsp;</p>\r\n', 'Листинг клонированных СТРАНИЦЫ - список-вид Как уже говорилось,  http://www.mytestsite.com/blog.php  является вид, в котором перечислены все существующие записи в блоге. доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от  blog.php  шаблона в порядке убывания их даты публикации. То, как мы настроили его, шаблон  blog.php  использует встроенный шаблон  blog_list.html  оказывать-список вид . файла  blog_list.html  , где мы будем делать изменения сейчас. Откройте его в текстовом редакторе. Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. Синтаксис страниц тег довольно прост.   Листинг клонированных СТРАНИЦЫ - список-вид Как уже говорилось,  http://www.mytestsite.com/blog.php  является вид, в котором перечислены все существующие записи в блоге. доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от  blog.php  шаблона в порядке убывания их даты публикации. То, как мы настроили его, шаблон  blog.php  использует встроенный шаблон  blog_list.html  оказывать-список вид . файла  blog_list.html  , где мы будем делать изменения сейчас. Откройте его в текстовом редакторе. Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. Синтаксис страниц тег довольно прост.  '),
(5, 6, ':hi-tech-technology-hard-drive.jpg', 'hi-tech-technology-hard-drive.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `couch_fields`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_fields`;
CREATE TABLE IF NOT EXISTS `couch_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `k_desc` varchar(255) DEFAULT NULL,
  `k_type` varchar(128) NOT NULL,
  `hidden` int(1) DEFAULT NULL,
  `search_type` varchar(20) DEFAULT 'text',
  `k_order` int(11) DEFAULT NULL,
  `data` longtext,
  `default_data` longtext,
  `required` int(1) DEFAULT NULL,
  `deleted` int(1) DEFAULT NULL,
  `validator` varchar(255) DEFAULT NULL,
  `validator_msg` text,
  `k_separator` varchar(20) DEFAULT NULL,
  `val_separator` varchar(20) DEFAULT NULL,
  `opt_values` text,
  `opt_selected` tinytext,
  `toolbar` varchar(20) DEFAULT NULL,
  `custom_toolbar` text,
  `css` text,
  `custom_styles` text,
  `maxlength` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `k_group` varchar(128) DEFAULT NULL,
  `collapsed` int(1) DEFAULT NULL,
  `assoc_field` varchar(128) DEFAULT NULL,
  `crop` int(1) DEFAULT '0',
  `enforce_max` int(1) DEFAULT '1',
  `quality` int(11) DEFAULT NULL,
  `show_preview` int(1) DEFAULT '0',
  `preview_width` int(11) DEFAULT NULL,
  `preview_height` int(11) DEFAULT NULL,
  `no_xss_check` int(1) DEFAULT '0',
  `rtl` int(1) DEFAULT '0',
  `body_id` tinytext,
  `body_class` tinytext,
  `disable_uploader` int(1) DEFAULT '0',
  `_html` text COMMENT 'Internal',
  `dynamic` text,
  `custom_params` text,
  PRIMARY KEY (`id`),
  KEY `couch_fields_index01` (`k_group`,`k_order`,`id`),
  KEY `couch_fields_Index02` (`template_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `couch_fields`
--

INSERT INTO `couch_fields` (`id`, `template_id`, `name`, `label`, `k_desc`, `k_type`, `hidden`, `search_type`, `k_order`, `data`, `default_data`, `required`, `deleted`, `validator`, `validator_msg`, `k_separator`, `val_separator`, `opt_values`, `opt_selected`, `toolbar`, `custom_toolbar`, `css`, `custom_styles`, `maxlength`, `height`, `width`, `k_group`, `collapsed`, `assoc_field`, `crop`, `enforce_max`, `quality`, `show_preview`, `preview_width`, `preview_height`, `no_xss_check`, `rtl`, `body_id`, `body_class`, `disable_uploader`, `_html`, `dynamic`, `custom_params`) VALUES
(1, 1, 'main_content', '', '', 'richtext', 0, 'text', 0, NULL, '\n		\n		<div class="grid_8">\n			<h4 class="page_title">Our mission</h4>\n			<div class="hr dotted clearfix">&nbsp;</div>\n			<p><i>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</i></p> \n			<h4 class="page_title">So who are we?</h4>\n			<div class="hr dotted clearfix">&nbsp;</div>\n			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p> \n			<h4 class="page_title">Staff</h4>\n			<div class="hr dotted clearfix">&nbsp;</div>\n			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p> \n			<h4 class="page_title">Clients</h4>\n			<div class="hr dotted clearfix">&nbsp;</div>\n			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p> \n			\n		</div>\n		', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 0, '', 0, 0, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''main_content''\r\ntype=''richtext''/>', '', NULL),
(2, 1, 'sec_content', '', '', 'richtext', 0, 'text', 0, NULL, '\n		<div class="grid_4">\n		\n			<h4>Our History</h4>\n			<div class="hr dotted clearfix">&nbsp;</div>\n			<dl class="history"> \n				<dt>1994</dt> \n				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> \n			\n				<dt>1996</dt> \n				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> \n			\n				<dt>2000</dt> \n				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> \n			\n				<dt>2003</dt> \n				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> \n			\n				<dt>2009</dt> \n				<dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> \n			</dl>\n		</div>\n		', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 0, '', 0, 0, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''sec_content''\r\ntype=''richtext''/>', '', NULL),
(3, 2, 'blog_con', '', '', 'richtext', 0, 'text', 0, NULL, '', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 0, '', 0, 0, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''blog_con''\r\ntype=''richtext''/>', '', NULL),
(4, 2, 'blog_img', '', '', 'image', 0, 'text', 0, NULL, '', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 150, 610, '', 0, '', 1, 1, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''blog_img''\r\ncrop=''1''\r\nwidth=''610''\r\nheight=''150''\r\ntype=''image''/>', '', NULL),
(5, 3, 'blog_con', '', '', 'richtext', 0, 'text', 0, NULL, '', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 0, 0, '', 0, '', 0, 0, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''blog_con''\r\ntype=''richtext''/>', '', NULL),
(6, 3, 'blog_img', '', '', 'image', 0, 'text', 0, NULL, '', 0, 0, '', '', '', '', '', '', '', '', '', '', 0, 150, 610, '', 0, '', 1, 1, 80, 0, 0, 0, 0, 0, '', '', 0, '<cms:editable\r\nname=''blog_img''\r\ncrop=''1''\r\nwidth=''610''\r\nheight=''150''\r\ntype=''image''/>', '', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `couch_folders`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_folders`;
CREATE TABLE IF NOT EXISTS `couch_folders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT '-1',
  `template_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `k_desc` mediumtext,
  `image` text,
  `access_level` int(11) DEFAULT '0',
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `couch_folders_Index02` (`template_id`,`name`),
  KEY `couch_folders_Index01` (`template_id`,`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `couch_folders`
--

INSERT INTO `couch_folders` (`id`, `pid`, `template_id`, `name`, `title`, `k_desc`, `image`, `access_level`, `weight`) VALUES
(1, -1, 2, 'news', 'News', '', NULL, 0, 0),
(2, -1, 3, 'news', 'News', '', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `couch_fulltext`
--
-- Создание: Окт 21 2014 г., 16:39
-- Последнее обновление: Окт 23 2014 г., 19:49
-- Последняя проверка: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_fulltext`;
CREATE TABLE IF NOT EXISTS `couch_fulltext` (
  `page_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`page_id`),
  FULLTEXT KEY `couch_fulltext_Index01` (`title`),
  FULLTEXT KEY `couch_fulltext_Index02` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `couch_fulltext`
--

INSERT INTO `couch_fulltext` (`page_id`, `title`, `content`) VALUES
(1, 'Default page for about.php * PLEASE CHANGE THIS TITLE *', ''),
(2, 'Hi ALL', 'Hello WORLD! '),
(3, 'Вторая запись)', 'Хело Ворлд, ахахха  Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS-Нажмите на название любого сообщению чтобы убедиться, что он загружает страницу-вид этой должности. Все выглядит хорошо на данный момент. &quot;Подробнее .. &#039; кнопку в нижней части каждой должности необходим внимание. Обычно, когда сообщение в блоге является отображается в его страницу-зрения (т.е. отдельно), отображается вся его содержание. Однако, когда же сообщение отображается в списке-зрения (с несколькими другими сообщений) это прагматичный, чтобы отобразить только выдержку из его содержания и обеспечить связь, что приводит к его страницу на море. Couch имеет два тега, которые можно использовать получить выписку из любых данных, полученных им -. выдержке и excerptHTML Разница между ними, конечно, является то, что excerptHTML сохраняет HTML элементов, присутствующих в входе, а выдержка отбрасывает все HTML-теги. Мы будем использовать тег excerptHTML для наших целей. Он может быть дополнительно настроен игнорировать определенные теги HTML. Мы будем делать это игнорировать любой тег IMG, потому что, если оно произойдет, будет присутствовать в выписке это, конечно, собирается сделать сообщение выше, чего мы желаем. Мы установим счетчик слов для выписки до 75. Модифицированный код IS- '),
(4, 'Привет', 'Привет, сайт еще в разработке  '),
(5, 'Еще раз', 'Листинг клонированных СТРАНИЦЫ - список-вид Как уже говорилось,  http://www.mytestsite.com/blog.php  является вид, в котором перечислены все существующие записи в блоге. доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от  blog.php  шаблона в порядке убывания их даты публикации. То, как мы настроили его, шаблон  blog.php  использует встроенный шаблон  blog_list.html  оказывать-список вид . файла  blog_list.html  , где мы будем делать изменения сейчас. Откройте его в текстовом редакторе. Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. Синтаксис страниц тег довольно прост.   Листинг клонированных СТРАНИЦЫ - список-вид Как уже говорилось,  http://www.mytestsite.com/blog.php  является вид, в котором перечислены все существующие записи в блоге. доступ к нему через ваш браузер и вы увидите, что в настоящее время он показывает некоторую трудно закодированный HTML. Мы собираемся изменить, что теперь, чтобы сделать его отображения страниц клонированных от  blog.php  шаблона в порядке убывания их даты публикации. То, как мы настроили его, шаблон  blog.php  использует встроенный шаблон  blog_list.html  оказывать-список вид . файла  blog_list.html  , где мы будем делать изменения сейчас. Откройте его в текстовом редакторе. Couch имеет тег по имени страницы, которые используются для перечисления или список страниц, принадлежащие к определенной шаблона. Возьмем немного обзор того, как работает этот тег, прежде чем положить его в реальном использовании. Синтаксис страниц тег довольно прост.   ');

-- --------------------------------------------------------

--
-- Структура таблицы `couch_levels`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_levels`;
CREATE TABLE IF NOT EXISTS `couch_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `k_level` int(11) DEFAULT '0',
  `disabled` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `couch_levels_index01` (`k_level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `couch_levels`
--

INSERT INTO `couch_levels` (`id`, `name`, `title`, `k_level`, `disabled`) VALUES
(1, 'superadmin', 'Super Admin', 10, 0),
(2, 'admin', 'Administrator', 7, 0),
(3, 'authenticated_user_special', 'Authenticated User (Special)', 4, 0),
(4, 'authenitcated_user', 'Authenticated User', 2, 0),
(5, 'unauthenticated_user', 'Everybody', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `couch_pages`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_pages`;
CREATE TABLE IF NOT EXISTS `couch_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `page_title` varchar(255) DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `creation_date` datetime DEFAULT '0000-00-00 00:00:00',
  `modification_date` datetime DEFAULT '0000-00-00 00:00:00',
  `publish_date` datetime DEFAULT '0000-00-00 00:00:00',
  `status` int(11) DEFAULT NULL,
  `is_master` int(1) DEFAULT '0',
  `page_folder_id` int(11) DEFAULT '-1',
  `access_level` int(11) DEFAULT '0',
  `comments_count` int(11) DEFAULT '0',
  `comments_open` int(1) DEFAULT '1',
  `nested_parent_id` int(11) DEFAULT '-1',
  `weight` int(11) DEFAULT '0',
  `show_in_menu` int(1) DEFAULT '1',
  `menu_text` varchar(255) DEFAULT NULL,
  `is_pointer` int(1) DEFAULT '0',
  `pointer_link` text,
  `pointer_link_detail` text,
  `open_external` int(1) DEFAULT '0',
  `masquerades` int(1) DEFAULT '0',
  `strict_matching` int(1) DEFAULT '0',
  `file_name` varchar(260) DEFAULT NULL,
  `file_ext` varchar(20) DEFAULT NULL,
  `file_size` int(11) DEFAULT '0',
  `file_meta` text,
  `creation_IP` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `couch_pages_Index03` (`template_id`,`page_name`),
  KEY `couch_pages_Index01` (`template_id`,`publish_date`),
  KEY `couch_pages_Index02` (`template_id`,`page_folder_id`,`publish_date`),
  KEY `couch_pages_Index04` (`template_id`,`modification_date`),
  KEY `couch_pages_Index05` (`template_id`,`page_folder_id`,`modification_date`),
  KEY `couch_pages_Index06` (`template_id`,`page_folder_id`,`page_name`),
  KEY `couch_pages_Index07` (`template_id`,`comments_count`),
  KEY `couch_pages_Index08` (`template_id`,`page_title`),
  KEY `couch_pages_Index09` (`template_id`,`page_folder_id`,`page_title`),
  KEY `couch_pages_Index10` (`template_id`,`page_folder_id`,`comments_count`),
  KEY `couch_pages_Index11` (`template_id`,`parent_id`,`modification_date`),
  KEY `couch_pages_Index12` (`parent_id`,`modification_date`),
  KEY `couch_pages_Index13` (`template_id`,`is_pointer`,`masquerades`,`pointer_link_detail`(255)),
  KEY `couch_pages_Index14` (`template_id`,`file_name`(255)),
  KEY `couch_pages_Index15` (`template_id`,`page_folder_id`,`file_name`(255)),
  KEY `couch_pages_Index16` (`template_id`,`file_ext`,`file_name`(255)),
  KEY `couch_pages_Index17` (`template_id`,`page_folder_id`,`file_ext`,`file_name`(255)),
  KEY `couch_pages_Index18` (`template_id`,`file_size`),
  KEY `couch_pages_Index19` (`template_id`,`page_folder_id`,`file_size`),
  KEY `couch_pages_Index20` (`creation_IP`,`creation_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `couch_pages`
--

INSERT INTO `couch_pages` (`id`, `template_id`, `parent_id`, `page_title`, `page_name`, `creation_date`, `modification_date`, `publish_date`, `status`, `is_master`, `page_folder_id`, `access_level`, `comments_count`, `comments_open`, `nested_parent_id`, `weight`, `show_in_menu`, `menu_text`, `is_pointer`, `pointer_link`, `pointer_link_detail`, `open_external`, `masquerades`, `strict_matching`, `file_name`, `file_ext`, `file_size`, `file_meta`, `creation_IP`) VALUES
(1, 1, 0, 'Default page for about.php * PLEASE CHANGE THIS TITLE *', 'default-page-for-about-php-please-change-this-title', '2014-10-21 22:33:11', '2014-10-21 23:13:39', '2014-10-21 22:33:11', NULL, 1, -1, 0, 0, 1, -1, 0, 1, NULL, 0, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, '46.53.183.91'),
(2, 2, 0, 'Hi ALL', 'hi-all', '2014-10-21 23:30:56', '2014-10-22 01:15:12', '2014-10-21 23:30:56', NULL, 1, 1, 0, 0, 1, -1, 0, 1, NULL, 0, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, '46.53.183.91'),
(3, 2, 0, 'Вторая запись)', 'second-post', '2014-10-23 20:23:32', '2014-10-23 23:02:13', '2014-10-23 20:21:33', NULL, 0, 1, 0, 0, 1, -1, 0, 1, NULL, 0, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, '46.53.183.91'),
(4, 3, 0, 'Привет', 'hello', '2014-10-23 21:05:57', '2014-10-23 21:54:21', '2014-10-23 21:05:57', NULL, 1, 2, 0, 0, 1, -1, 0, 1, NULL, 0, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, '46.53.183.91'),
(5, 3, 0, 'Еще раз', 'all', '2014-10-23 22:49:23', '2014-10-23 22:49:42', '2014-10-23 22:47:35', NULL, 0, 2, 0, 0, 1, -1, 0, 1, NULL, 0, NULL, NULL, 0, 0, 0, NULL, NULL, 0, NULL, '46.53.183.91');

-- --------------------------------------------------------

--
-- Структура таблицы `couch_relations`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_relations`;
CREATE TABLE IF NOT EXISTS `couch_relations` (
  `pid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`pid`,`fid`,`cid`),
  KEY `couch_relations_Index01` (`pid`,`fid`,`weight`),
  KEY `couch_relations_Index02` (`fid`,`cid`,`weight`),
  KEY `couch_relations_Index03` (`cid`,`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `couch_settings`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_settings`;
CREATE TABLE IF NOT EXISTS `couch_settings` (
  `k_key` varchar(255) NOT NULL,
  `k_value` longtext,
  PRIMARY KEY (`k_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `couch_settings`
--

INSERT INTO `couch_settings` (`k_key`, `k_value`) VALUES
('k_couch_version', '1.4'),
('nonce_secret_key', 'eKZhZAvLUnfEv6HdyxlcnPrcsODPD3nieNZDNVO7IubD0jgZg2B4itGaHKqLdetR'),
('secret_key', 'LH45sIgJZp26JGgkfbvbP66pHGfHxUmJ2QeUZU3oKvVTCCDieyTt5qjcwZkuj6DL');

-- --------------------------------------------------------

--
-- Структура таблицы `couch_templates`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_templates`;
CREATE TABLE IF NOT EXISTS `couch_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `clonable` int(1) DEFAULT '0',
  `executable` int(1) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `access_level` int(11) DEFAULT '0',
  `commentable` int(1) DEFAULT '0',
  `hidden` int(1) DEFAULT '0',
  `k_order` int(11) DEFAULT '0',
  `dynamic_folders` int(1) DEFAULT '0',
  `nested_pages` int(1) DEFAULT '0',
  `gallery` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `couch_templates_Index01` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `couch_templates`
--

INSERT INTO `couch_templates` (`id`, `name`, `description`, `clonable`, `executable`, `title`, `access_level`, `commentable`, `hidden`, `k_order`, `dynamic_folders`, `nested_pages`, `gallery`) VALUES
(1, 'about.php', '', 0, 1, NULL, 0, 0, 0, 0, 0, 0, 0),
(2, 'blog.php', '', 1, 1, 'Blog', 0, 1, 0, 0, 0, 0, 0),
(3, 'full.php', '', 1, 1, 'Full', 0, 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `couch_users`
--
-- Создание: Окт 21 2014 г., 16:39
--

DROP TABLE IF EXISTS `couch_users`;
CREATE TABLE IF NOT EXISTS `couch_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `password` varchar(64) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activation_key` varchar(64) DEFAULT NULL,
  `registration_date` datetime DEFAULT NULL,
  `access_level` int(11) DEFAULT '0',
  `disabled` int(11) DEFAULT '0',
  `system` int(11) DEFAULT '0',
  `last_failed` bigint(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `couch_users_email` (`email`),
  UNIQUE KEY `couch_users_name` (`name`),
  KEY `couch_users_activation_key` (`activation_key`),
  KEY `couch_users_index01` (`access_level`),
  KEY `couch_users_index02` (`access_level`,`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `couch_users`
--

INSERT INTO `couch_users` (`id`, `name`, `title`, `password`, `email`, `activation_key`, `registration_date`, `access_level`, `disabled`, `system`, `last_failed`) VALUES
(1, 'dolfst', 'dolfst', '$P$BALq23k3tMabFfn.c4d8slzrrLNXu30', 'Dolfst@gmail.com', '', '2014-10-21 22:09:22', 10, 0, 1, 1414084257);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
